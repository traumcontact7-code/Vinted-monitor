# 🛍️ Vinted Monitor Bot

Bot Discord de surveillance Vinted en temps réel. Recevez des notifications instantanées dès qu'une nouvelle annonce correspond à vos critères de recherche.

## ✨ Fonctionnalités

- 📡 **Surveillance en temps réel** — vérifie les nouvelles annonces toutes les X secondes
- 🌍 **Multi-pays** — FR, BE, DE, NL, ES, IT, PL, UK, LU, PT, AT, CZ, SK, HU, RO, LT, LV, FI, SE, DK
- 💶 **Filtres prix** — ne recevoir que les annonces dans votre budget
- 🎨 **Embeds riches** — photo, prix, état, marque, taille, vendeur, stats
- 💾 **Persistance** — les surveillances survivent aux redémarrages du bot
- 📊 **Multi-serveur** — jusqu'à 20 surveillances par serveur Discord
- 🔄 **Déduplication** — aucun doublon, jamais

## 📋 Prérequis

- Node.js 18+
- Un bot Discord (créé sur [discord.com/developers](https://discord.com/developers))

## 🚀 Installation

```bash
# 1. Cloner le dépôt
git clone <repo> vinted-bot
cd vinted-bot

# 2. Installer les dépendances
npm install

# 3. Configurer le bot
# Édite config.json avec ton token et client ID
```

## ⚙️ Configuration

Édite `config.json` :

```json
{
  "token": "TON_BOT_TOKEN_ICI",
  "clientId": "TON_CLIENT_ID_ICI"
}
```

### Obtenir ces valeurs :
1. Va sur [discord.com/developers/applications](https://discord.com/developers/applications)
2. Crée une nouvelle application → onglet **Bot**
3. Copie le **Token**
4. Dans **General Information**, copie l'**Application ID** (= clientId)

### Permissions bot requises :
- `Send Messages`
- `Embed Links`
- `Read Message History`
- Scope: `bot` + `applications.commands`

## 🎯 Démarrage

```bash
# Déployer les commandes slash (une seule fois)
npm run deploy

# Lancer le bot
npm start

# En développement (auto-restart)
npm run dev
```

## 📌 Commandes

| Commande | Description |
|----------|-------------|
| `/add url:<url> label:<nom>` | Ajouter une surveillance |
| `/add ... intervalle:<sec>` | Définir l'intervalle (30-3600s) |
| `/add ... prix_min:<€> prix_max:<€>` | Filtrer par prix |
| `/add ... canal:<#canal>` | Choisir le canal de notification |
| `/remove id:<ID>` | Supprimer une surveillance |
| `/list` | Voir toutes les surveillances actives |
| `/ping` | Tester la latence |
| `/help` | Afficher l'aide |

## 💡 Utilisation

1. Va sur **vinted.fr** et configure ta recherche (mots-clés, marque, taille, état...)
2. Copie l'URL complète depuis la barre d'adresse
3. Dans Discord : `/add url:<url_copiée> label:Air Jordan 1`
4. Les nouvelles annonces arrivent automatiquement dans le canal !

### Exemple d'URL Vinted :
```
https://www.vinted.fr/vetements?search_text=jordan+1&brand_ids=53&price_to=80
```

## 📁 Structure

```
vinted-bot/
├── src/
│   ├── index.js              # Point d'entrée
│   ├── api/
│   │   └── vinted.js         # Client API Vinted
│   ├── monitors/
│   │   └── MonitorManager.js # Gestion des surveillances
│   ├── commands/
│   │   ├── add.js            # /add
│   │   ├── remove.js         # /remove
│   │   ├── list.js           # /list
│   │   ├── ping.js           # /ping
│   │   └── help.js           # /help
│   ├── handlers/
│   │   └── commandHandler.js # Chargeur de commandes
│   └── utils/
│       └── embedBuilder.js   # Construction des embeds
├── scripts/
│   └── deploy.js             # Déploiement des commandes slash
├── data/                     # Créé automatiquement (surveillances)
├── config.json               # Token & Client ID
└── package.json
```

## ⚠️ Notes importantes

- **Cloudflare** : Vinted utilise Cloudflare pour protéger son API. Le bot gère les cookies automatiquement, mais avec trop de requêtes ou une IP bannie, certaines surveillances peuvent échouer temporairement.
- **Intervalle minimum** : 30 secondes pour éviter les blocages.
- **Usage responsable** : Ce bot lit des données publiquement accessibles sur Vinted, comme n'importe quel navigateur.
